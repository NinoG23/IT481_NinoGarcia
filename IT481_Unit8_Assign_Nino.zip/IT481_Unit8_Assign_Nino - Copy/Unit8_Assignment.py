## https://www.geeksforgeeks.org/merge-sort/


import random
import time


# DATASET GENERATION

def generate_dataset(size):
    return [random.randint(1, 1000000) for _ in range(size)]

small = generate_dataset(10)
medium = generate_dataset(1000)
large = generate_dataset(10000)


# ORIGINAL MERGE SORT

def merge_sort(arr):
    if len(arr) <= 1:
        return arr

    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])

    return merge(left, right)

def merge(left, right):
    merged = []
    i = j = 0

    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            merged.append(left[i])
            i += 1
        else:
            merged.append(right[j])
            j += 1

    merged.extend(left[i:])
    merged.extend(right[j:])
    return merged


# TIMING FUNCTION

def time_sort(sort_func, dataset):
    data_copy = dataset.copy()
    start = time.time()
    sort_func(data_copy)
    end = time.time()
    return end - start


# BASELINE RESULTS

baseline_small = time_sort(merge_sort, small)
baseline_medium = time_sort(merge_sort, medium)
baseline_large = time_sort(merge_sort, large)

print("Baseline Times:")
print("Small:", baseline_small)
print("Medium:", baseline_medium)
print("Large:", baseline_large)


# OPTIMIZED VERSION OF MERGE SORT
# Optimization: Use iterative merge sort (less overhead)

def merge_sort_iterative(arr):
    width = 1
    n = len(arr)

    while width < n:
        for i in range(0, n, 2 * width):
            left = arr[i : i + width]
            right = arr[i + width : i + 2 * width]

            # Merge subarrays in place
            merged = []
            li = ri = 0
            while li < len(left) and ri < len(right):
                if left[li] < right[ri]:
                    merged.append(left[li])
                    li += 1
                else:
                    merged.append(right[ri])
                    ri += 1
            merged.extend(left[li:])
            merged.extend(right[ri:])
            arr[i : i + len(merged)] = merged
        width *= 2
    
    return arr


# OPTIMIZED RESULTS

opt_small = time_sort(merge_sort_iterative, small)
opt_medium = time_sort(merge_sort_iterative, medium)
opt_large = time_sort(merge_sort_iterative, large)

print("Optimized Times:")
print("Small:", opt_small)
print("Medium:", opt_medium)
print("Large:", opt_large)
